package com.example.vpnstarter

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VpnHome() }
    }
}

private val bg = Color(0xFF101827)
private val panel = Color(0xFF182235)
private val muted = Color(0xFF8FA0BD)
private val accent = Color(0xFF63C5A6)

@Composable
fun VpnHome() {
    var connected by remember { mutableStateOf(false) }
    Surface(color = bg, modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(24.dp)) {
                Row(Modifier.fillMaxWidth().padding(18.dp), horizontalArrangement = Arrangement.End) {
                    Text("اسم المستخدم: ", color = muted)
                    Text("AHMAD", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(18.dp))
            Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(24.dp)) {
                Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    InfoTile("البيانات المتبقية", "المتبقي", "150 MB", Modifier.weight(1f))
                    InfoTile("الوقت المتبقي", "مفتوح", "", Modifier.weight(1f))
                }
                Text("0 KB / 150 MB     •     تتجدد بعد 22 دقيقة", color = muted,
                    modifier = Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 18.dp),
                    textAlign = TextAlign.Center, fontSize = 13.sp)
            }
            Spacer(Modifier.height(34.dp))
            Box(
                modifier = Modifier.size(230.dp).background(Color(0xFF131D30), CircleShape)
                    .border(2.dp, Color(0xFF263149), CircleShape)
                    .clickable { connected = !connected },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.PowerSettingsNew, contentDescription = "تشغيل VPN",
                    tint = if (connected) accent else muted, modifier = Modifier.size(100.dp))
            }
            Spacer(Modifier.height(26.dp))
            Text(if (connected) "00:00:01" else "00:00:00", color = muted, fontSize = 34.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Surface(color = Color(0xFF121C2E), shape = RoundedCornerShape(30.dp)) {
                Text(if (connected) "متصل (واجهة تجريبية)" else "غير متصل",
                    color = if (connected) accent else muted, modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp))
            }
            Spacer(Modifier.weight(1f))
            Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(22.dp)) {
                Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("🇸🇾", fontSize = 26.sp)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("الخادم سوريا", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        Text("server.example.com", color = muted)
                    }
                    Text("●●●●", color = accent)
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                SpeedCard("رفع", "0 KB/s", Icons.Default.ArrowUpward, Modifier.weight(1f))
                SpeedCard("تنزيل", "0 KB/s", Icons.Default.ArrowDownward, Modifier.weight(1f))
            }
            Spacer(Modifier.height(18.dp))
            Text("نسخة تجريبية 1.0 — واجهة فقط، ليست VPN فعلياً بعد", color = muted, fontSize = 12.sp)
        }
    }
}

@Composable
fun InfoTile(top: String, middle: String, bottom: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Color(0xFF131D30)),
        shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(top, color = muted, fontSize = 14.sp)
            Spacer(Modifier.height(14.dp))
            Text(middle, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            if (bottom.isNotEmpty()) Text(bottom, color = muted, fontWeight = FontWeight.Bold, fontSize = 22.sp)
        }
    }
}

@Composable
fun SpeedCard(label: String, speed: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(22.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = accent)
            Spacer(Modifier.width(10.dp))
            Column {
                Text(label, color = muted)
                Text(speed, color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}
